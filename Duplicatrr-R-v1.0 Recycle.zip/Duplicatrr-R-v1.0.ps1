# =========================================================================================
# Plex Duplicate Manager (DUPLICATRR - Recycle Bin Mode)
# =========================================================================================

# --- Configuration ---
$PlexUrl   = "http://127.0.0.1:32400"  # Change if your server is on a different IP/port
$PlexToken = "sz5oTyHxq_gz9vdE8N6o"    # Your active Plex token

# --- Helper Functions ---
function Get-PlexData {
    param([string]$Path)
    $Separator = if ($Path.Contains("?")) { "&" } else { "?" }
    $Uri = "{0}{1}{2}X-Plex-Token={3}" -f $PlexUrl, $Path, $Separator, $PlexToken
    try {
        return Invoke-RestMethod -Uri $Uri -Method Get -Headers @{ "Accept" = "application/json" } -ErrorAction Stop
    }
    catch {
        Write-Host "[-] Error connecting to Plex API: $_" -ForegroundColor Red
        return $null
    }
}

function Remove-LocalFile {
    param([string]$FilePath)
    if (Test-Path -LiteralPath $FilePath) {
        try {
            Write-Host ("[*] Moving local file to Recycle Bin: {0}" -f $FilePath) -ForegroundColor Yellow
            
            # Use Windows Shell API to send the file to the Recycle Bin safely (handles literal bracket paths)
            $Shell = New-Object -ComObject Shell.Application
            $Folder = $Shell.NameSpace((Split-Path $FilePath))
            $Item = $Folder.ParseName((Split-Path $FilePath -Leaf))
            $Item.InvokeVerb("delete")
            
            Write-Host "[+] Local file successfully moved to Recycle Bin!" -ForegroundColor Green
        }
        catch {
            Write-Host ("[-] Failed to recycle file: {0}" -f $_.Exception.Message) -ForegroundColor Red
        }
    } else {
        Write-Host ("[!] File path not found or unreachable on disk: {0}" -f $FilePath) -ForegroundColor Red
    }
}

# --- Main Script Logic ---
clear
$Index = 0

if ([string]::IsNullOrEmpty($PlexToken)) {
    Write-Host "[!] Please configure your Plex Token inside the script first!" -ForegroundColor Yellow
    Exit
}

Write-Host "[*] Fetching Plex libraries..." -ForegroundColor Cyan
$SectionsContainer = Get-PlexData -Path "/library/sections"

if (-not $SectionsContainer -or -not $SectionsContainer.MediaContainer.Directory) {
    Write-Host "[-] No libraries found or unable to connect. (Check your Token or URL!)" -ForegroundColor Red
    Exit
}

$Libraries = $SectionsContainer.MediaContainer.Directory

# --- Menu Loop ---
while ($true) {
    clear
    Write-Host "=========================================" -ForegroundColor Magenta
    Write-Host "               DUPLICATRR                " -ForegroundColor Magenta
    Write-Host "=========================================" -ForegroundColor Magenta
    Write-Host ""
    
    for ($i = 0; $i -lt $Libraries.Count; $i++) {
        Write-Host ("{0}. {1} ({2})" -f ($i + 1), $Libraries[$i].title, $Libraries[$i].type) -ForegroundColor White
    }
    Write-Host ("{0}. Exit" -f ($Libraries.Count + 1)) -ForegroundColor Yellow
    Write-Host ""
    
    $Selection = Read-Host "Select a library number"
    
    if ($Selection -eq ($Libraries.Count + 1)) {
        Write-Host "[*] Exiting script. Goodbye!" -ForegroundColor Cyan
        break
    }
    
    if (-not [int]::TryParse($Selection, [ref]$Index) -or $Index -lt 1 -or $Index -gt $Libraries.Count) {
        Write-Host "[!] Invalid choice, press Enter to try again..." -ForegroundColor Yellow
        [void][Console]::ReadLine()
        continue
    }
    
    $SelectedLib = $Libraries[$Index - 1]
    
    # --- Mode Selection Menu ---
    Write-Host ""
    Write-Host "Select scanning and deletion mode:" -ForegroundColor Cyan
    Write-Host "1. Single Deletion (Go through titles one by one)" -ForegroundColor White
    Write-Host "2. Bulk Deletion   (Show all duplicates first, then mass delete)" -ForegroundColor White
    $ModeSelection = Read-Host "Enter choice (1 or 2)"
    
    if ($ModeSelection -ne "1" -and $ModeSelection -ne "2") {
        Write-Host "[!] Invalid mode selected. Press Enter to return to main menu..." -ForegroundColor Yellow
        [void][Console]::ReadLine()
        continue
    }
    
    Write-Host ("`n[*] Scanning '{0}' for duplicates..." -f $SelectedLib.title) -ForegroundColor Cyan
    
    $DuplicatePath = "/library/sections/{0}/all?all=1&duplicates=1" -f $SelectedLib.key
    $DuplicateContainer = Get-PlexData -Path $DuplicatePath
    
    if ($null -eq $DuplicateContainer) {
        Write-Host "[-] Failed to fetch library items. Press Enter to return to menu..." -ForegroundColor Red
        [void][Console]::ReadLine()
        continue
    }
    
    $MediaItems = $DuplicateContainer.MediaContainer.Metadata
    
    if (-not $MediaItems -or $MediaItems.Count -eq 0) {
        Write-Host "[+] Clear! No duplicate items found in this library." -ForegroundColor Green
        Write-Host "Press Enter to return to menu..."
        [void][Console]::ReadLine()
        continue
    }
    
    Write-Host ("`n[*] Processing metadata for {0} potential duplicate entries..." -f $MediaItems.Count) -ForegroundColor Yellow
    
    $MasterFilesList = @()
    
    foreach ($Item in $MediaItems) {
        $ItemDetailPath = "/library/metadata/{0}" -f $Item.ratingKey
        $DetailContainer = Get-PlexData -Path $ItemDetailPath
        
        $TargetItem = $Item
        if ($null -ne $DetailContainer -and $null -ne $DetailContainer.MediaContainer.Metadata) {
            $TargetItem = $DetailContainer.MediaContainer.Metadata[0]
        }
        
        if ($null -ne $TargetItem.Media) {
            foreach ($Media in $TargetItem.Media) {
                if ($null -ne $Media.Part) {
                    foreach ($Part in $Media.Part) {
                        $Width = if ($Media.width) { $Media.width } else { 0 }
                        $Bitrate = if ($Media.bitrate) { $Media.bitrate } else { 0 }
                        $Res = if ($Media.videoResolution) { $Media.videoResolution } else { "Unknown" }
                        
                        $SizeBytes = if ($Part.size) { $Part.size } else { 0 }
                        $SizeGB = [math]::Round(($SizeBytes / 1GB), 2)
                        
                        $RawFile = if ($Part.file) { $Part.file } else { "Unknown Filename" }
                        $LeafName = Split-Path $RawFile -Leaf
                        
                        $MasterFilesList += [PSCustomObject]@{
                            PartId     = $Part.id
                            RatingKey  = $TargetItem.ratingKey
                            Title      = $TargetItem.title
                            Year       = $TargetItem.year
                            File       = $RawFile
                            Width      = $Width
                            Bitrate    = $Bitrate
                            SizeBytes  = $SizeBytes
                            Display    = ("{0}p | {1} GB | {2} kbps | {3}" -f $Res, $SizeGB, [math]::Round($Bitrate/1000), $LeafName)
                        }
                    }
                }
            }
        }
    }
    
    # Group entries by Title and Year
    $GroupedDuplicates = $MasterFilesList | Group-Object -Property Title, Year | Where-Object { $_.Count -gt 1 }
    
    # Final arrays for display processing
    $FinalValidGroups = @()
    
    foreach ($Group in $GroupedDuplicates) {
        # Sort current movie files by quality
        $SortedFiles = $Group.Group | Sort-Object Width, Bitrate -Descending
        $KeepFile = $SortedFiles[0]
        
        # AIRTIGHT SAFETY FIX: Filter out any items that point to the exact same file path as the file we are keeping
        $LowerQualityDuplicates = $SortedFiles | Select-Object -Skip 1 | Where-Object { $_.File -ne $KeepFile.File }
        
        # Only process this title if there are genuine separate duplicate files remaining to delete
        if ($LowerQualityDuplicates.Count -gt 0) {
            $FinalValidGroups += [PSCustomObject]@{
                KeepFile  = $KeepFile
                Deletions = $LowerQualityDuplicates
                Title     = $KeepFile.Title
                Year      = $KeepFile.Year
            }
        }
    }
    
    if ($FinalValidGroups.Count -eq 0) {
        Write-Host "[+] Clear! No multi-file duplicates found after path verification filters." -ForegroundColor Green
        Write-Host "Press Enter to return to menu..."
        [void][Console]::ReadLine()
        continue
    }
    
    Write-Host ("`n[!] Found {0} unique titles with genuine separate duplicate files.`n" -f $FinalValidGroups.Count) -ForegroundColor Yellow
    
    # -------------------------------------------------------------------------------------
    # MODE 1: SINGLE DELETION (Interactive One-by-One)
    # -------------------------------------------------------------------------------------
    if ($ModeSelection -eq "1") {
        foreach ($Group in $FinalValidGroups) {
            Write-Host "--------------------------------------------------" -ForegroundColor Gray
            Write-Host ("Title: {0} ({1})" -f $Group.Title, $Group.Year) -ForegroundColor Cyan
            
            Write-Host "  [KEEPING]   -> " -NoNewline -ForegroundColor Green
            Write-Host $Group.KeepFile.Display
            Write-Host ("               Path: {0}" -f $Group.KeepFile.File) -ForegroundColor Gray
            Write-Host ""
            
            foreach ($Dup in $Group.Deletions) {
                Write-Host "  [DELETING]  -> " -NoNewline -ForegroundColor Red
                Write-Host $Dup.Display
                Write-Host ("               Path: {0}" -f $Dup.File) -ForegroundColor Gray
            }
            Write-Host ""
            
            $Action = Read-Host "Do you want to move the lower quality duplicate(s) to the Recycle Bin? (Y/N)"
            if ($Action -imatch "y") {
                $Confirm = Read-Host "Confirm moving file(s) to the Recycle Bin? (Y/N)"
                if ($Confirm -imatch "y") {
                    foreach ($Dup in $Group.Deletions) {
                        Remove-LocalFile -FilePath $Dup.File
                    }
                }
            }
        }
    }
    
    # -------------------------------------------------------------------------------------
    # MODE 2: BULK DELETION (Show All First, Tally Space, Then Mass Delete)
    # -------------------------------------------------------------------------------------
    elseif ($ModeSelection -eq "2") {
        $AllBulkDeletions = @()
        $TotalBytesToClear = 0
        
        foreach ($Group in $FinalValidGroups) {
            $AllBulkDeletions += $Group.Deletions
            
            foreach ($Dup in $Group.Deletions) {
                $TotalBytesToClear += $Dup.SizeBytes
            }
            
            Write-Host "--------------------------------------------------" -ForegroundColor Gray
            Write-Host ("Title: {0} ({1})" -f $Group.Title, $Group.Year) -ForegroundColor Cyan
            
            Write-Host "  [KEEPING]   -> " -NoNewline -ForegroundColor Green
            Write-Host $Group.KeepFile.Display
            Write-Host ("               Path: {0}" -f $Group.KeepFile.File) -ForegroundColor Gray
            Write-Host ""
            
            foreach ($Dup in $Group.Deletions) {
                Write-Host "  [DELETING]  -> " -NoNewline -ForegroundColor Red
                Write-Host $Dup.Display
                Write-Host ("               Path: {0}" -f $Dup.File) -ForegroundColor Gray
            }
            Write-Host ""
        }
        
        $TotalGBToClear = [math]::Round(($TotalBytesToClear / 1GB), 2)
        
        Write-Host "==================================================" -ForegroundColor Magenta
        Write-Host "                 SUMMARY TOTALS                   " -ForegroundColor Magenta
        Write-Host "==================================================" -ForegroundColor Magenta
        Write-Host ("  Files Slated for Removal : {0}" -f $AllBulkDeletions.Count) -ForegroundColor Yellow
        Write-Host ("  Total Storage to Recover : {0} GB" -f $TotalGBToClear) -ForegroundColor Green
        Write-Host "==================================================" -ForegroundColor Magenta
        Write-Host ""
        
        $Action = Read-Host "Do you want to move ALL lower quality duplicates to the Recycle Bin? (Y/N)"
        if ($Action -imatch "y") {
            $Confirm = Read-Host "Confirm batch moving all targeted files to the Recycle Bin? (Y/N)"
            if ($Confirm -imatch "y") {
                Write-Host "`n[*] Commencing bulk recycling execution..." -ForegroundColor Cyan
                foreach ($Dup in $AllBulkDeletions) {
                    Remove-LocalFile -FilePath $Dup.File
                }
            } else {
                Write-Host "[*] Bulk processing aborted by user." -ForegroundColor Yellow
            }
        } else {
            Write-Host "[*] Bulk processing aborted by user." -ForegroundColor Yellow
        }
    }
    
    Write-Host "`n[*] Review finished. Press Enter to return to the main menu..."
    [void][Console]::ReadLine()
}